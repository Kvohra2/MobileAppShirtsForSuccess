# MobileAppShirtsForSuccess
Code for a mobile application dedicated to microfinancing for impoverished nations.
